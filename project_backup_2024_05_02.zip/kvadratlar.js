let kvFullRecords = [];
let kvFilteredRecords = [];
const KV_ITEMS_PER_PAGE = 15;
let kvCurrentPage = 1;

const KV_MONTHS_UZ = ['', 'Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'Iyun', 'Iyul', 'Avgust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];

function kvMonthLabel(monthStr) {
    const clean = String(monthStr || '').replace(/^_+/, '').replace(/^'/, '');
    const num = parseInt(clean, 10);
    return (num >= 1 && num <= 12) ? KV_MONTHS_UZ[num] : (clean || '—');
}

let activeKvProc = null;

function kvShowProc(msg) {
    if (activeKvProc) kvHideProc();
    const toast = document.createElement('div');
    toast.className = 'kv-proc-toast';
    toast.innerHTML = `<div class="kv-spinner"></div><span>${escapeHtml(msg)}</span>`;
    document.body.appendChild(toast);
    activeKvProc = toast;
}

function kvHideProc(isSuccess = null, finalMsg = null) {
    if (!activeKvProc) return;
    const toast = activeKvProc;
    activeKvProc = null;
    if (isSuccess !== null) {
        toast.innerHTML = `<span>${isSuccess ? '✅' : '❌'}</span><span>${escapeHtml(finalMsg || (isSuccess ? 'Bajarildi' : 'Xatolik'))}</span>`;
        toast.classList.add(isSuccess ? 'success' : 'error');
        setTimeout(() => {
            toast.classList.add('hiding');
            setTimeout(() => toast.remove(), 300);
        }, 1500);
    } else {
        toast.remove();
    }
}

async function kvRefreshAll(btn) {
    if (btn) btn.classList.add('spinning');
    kvShowProc('Ma\'lumotlar yangilanmoqda...');
    try {
        await initKvadratTab();
        kvHideProc(true, 'Yangilandi');
    } catch (e) {
        kvHideProc(false, 'Yangilashda xato');
    } finally {
        const refreshButtons = document.querySelectorAll('.btn-secondary[title="Yangilash"]');
        refreshButtons.forEach(button => {
            button.classList.remove('spinning');
        });
    }
}

function populateKvadratMeta(staffList) {
    const staffFilter = document.getElementById('kvFilterStaff');
    const kvStaffModal = document.getElementById('kvStaffSelect');
    if (staffFilter) {
        staffFilter.innerHTML = '<option value="all">Barcha hodimlar</option>';
        staffList.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = name;
            staffFilter.appendChild(opt);
        });
    }
    if (kvStaffModal) {
        kvStaffModal.innerHTML = '<option value="">Hodimni tanlang...</option>';
        staffList.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = name;
            kvStaffModal.appendChild(opt);
        });
    }
    const yearSel = document.getElementById('kvFilterYear');
    if (yearSel) {
        const currentYear = new Date().getFullYear();
        yearSel.innerHTML = '<option value="all">Yillar</option>';
        for (let y = currentYear; y >= 2024; y--) {
            const opt = document.createElement('option');
            opt.value = y;
            opt.textContent = y;
            yearSel.appendChild(opt);
        }
    }
    const processSelect = document.getElementById('kvFilterProcess');
    if (processSelect) {
        const workflowConfig = (typeof myPermissions !== 'undefined' && Array.isArray(myPermissions.workflowConfig)) ? myPermissions.workflowConfig : [];
        processSelect.innerHTML = '<option value="all">Barcha jarayonlar</option>';
        workflowConfig.forEach((step, idx) => {
            const stepIndex = String(step.index || idx + 1);
            const label = escapeHtml(step.status || step.action || `Bosqich ${idx + 1}`);
            const opt = document.createElement('option');
            opt.value = stepIndex;
            opt.textContent = label;
            processSelect.appendChild(opt);
        });
        processSelect.value = 'all';
    }
    _initKvFormYears();
}

function _initKvFormYears() {
    const curYear = new Date().getFullYear();
    const curMonth = String(new Date().getMonth() + 1).padStart(2, '0');
    const yearEl = document.getElementById('kvActionYear');
    if (yearEl) {
        yearEl.innerHTML = '';
        for (let y = curYear + 1; y >= curYear - 2; y--) {
            const opt = document.createElement('option');
            opt.value = y;
            opt.textContent = y;
            if (y === curYear) opt.selected = true;
            yearEl.appendChild(opt);
        }
    }
    const monthEl = document.getElementById('kvActionMonth');
    if (monthEl) monthEl.value = curMonth;
}

async function initKvadratTab() {
    const listContainer = document.getElementById('kvList');
    if (!listContainer) return;
    listContainer.innerHTML = `<div class="kv-table-wrap"><table class="kv-table"><thead><tr><th>№</th><th>Buyurtma №</th><th>Oy</th><th>m²</th><th>ST</th></tr></thead><tbody>${Array(5).fill('<tr><td colspan="5"><div class="skeleton" style="height:25px;margin:5px 0;"></div></tr>').join('')}</tbody></table></div>`;
    try {
        const data = await apiRequest({
            action: 'kvadrat_get_all'
        });
        if (data.success) {
            kvFullRecords = data.data || [];
            if (typeof kvDashboardRecords !== 'undefined') {
                kvDashboardRecords = kvFullRecords;
            }
            applyKvFilters();
        } else {
            listContainer.innerHTML = `<div class="empty-state"><p style="color:var(--red);">❌ ${escapeHtml(data.error || 'Yuklashda xato')}</p></div>`;
        }
    } catch (e) {
        listContainer.innerHTML = `<div class="empty-state"><p style="color:var(--red);">❌ Tarmoq xatosi: ${escapeHtml(e.message)}</p></div>`;
    }
    updateKvFabVisibility();
}

function updateKvFabVisibility() {
    const fab = document.getElementById('nav-add');
    if (!fab) return;
    const activeTab = document.querySelector('.tab-content.active');
    if (activeTab && activeTab.id === 'kvadratTab') {
        const positions = (typeof myPermissions !== 'undefined' && myPermissions.positions) || [];
        const isLoyihachi = myRole === 'SuperAdmin' || positions.indexOf('Loyihachi') !== -1;
        fab.style.visibility = isLoyihachi ? 'visible' : 'hidden';
        fab.style.pointerEvents = isLoyihachi ? 'auto' : 'none';
        fab.style.opacity = isLoyihachi ? '1' : '0';
        fab.style.transition = 'opacity 0.2s';
    } else {
        fab.style.visibility = 'visible';
        fab.style.pointerEvents = 'auto';
        fab.style.opacity = '1';
    }
}

function renderKvList() {
    const container = document.getElementById('kvList');
    const totalDisplay = document.getElementById('kvTotalM2');
    if (!container) return;
    if (!kvFilteredRecords.length) {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon">📏</div><p>Ma'lumot topilmadi</p></div>`;
        if (totalDisplay) totalDisplay.innerText = '0';
        return;
    }

    let lastDavr = null;
    const sortedKvData = [...kvFilteredRecords].sort((a, b) => {
        // Yil va Oy bo'yicha saralash (Davr)
        const davrA = a.year && a.month ? `${a.year}-${String(a.month).replace('_', '').padStart(2, '0')}` : getDavrSortKey('', a.date, '');
        const davrB = b.year && b.month ? `${b.year}-${String(b.month).replace('_', '').padStart(2, '0')}` : getDavrSortKey('', b.date, '');
        
        if (davrB !== davrA) return davrB.localeCompare(davrA);
        
        // Agar davr bir xil bo'lsa, № bo'yicha (kattasi tepada)
        const noA = parseInt(a.no, 10) || 0;
        const noB = parseInt(b.no, 10) || 0;
        return noB - noA;
    });

    // Pagination logic
    const totalPages = Math.ceil(sortedKvData.length / KV_ITEMS_PER_PAGE);
    const start = (kvCurrentPage - 1) * KV_ITEMS_PER_PAGE;
    const end = start + KV_ITEMS_PER_PAGE;
    const paginatedData = sortedKvData.slice(start, end);

    const fragment = document.createDocumentFragment();
    const wrap = document.createElement('div');
    wrap.className = 'kv-table-wrap';
    const table = document.createElement('table');
    table.className = 'kv-table';
    table.innerHTML = `<thead><tr><th>№</th><th>Buyurtma №</th><th>Oy</th><th style="text-align:right;">m²</th><th>ST</th></tr></thead>`;
    const tbody = document.createElement('tbody');

    const totalM2ForFiltered = kvFilteredRecords.reduce((sum, rec) => sum + (Number(rec.totalM2) || 0), 0);

    paginatedData.forEach((rec, loopIdx) => {
        const globalIdx = (kvCurrentPage - 1) * KV_ITEMS_PER_PAGE + loopIdx;
        const origIdx = kvFilteredRecords.indexOf(rec);

        const currentDavr = rec.year && rec.month ? `${rec.year}-${String(rec.month).replace('_', '').padStart(2, '0')}` : getDavrSortKey('', rec.date, '');
        let relDavr = getDavrLabel(currentDavr);

        if (relDavr !== lastDavr) {
            const trDate = document.createElement('tr');
            trDate.className = 'kv-date-row';
            trDate.innerHTML = `<td colspan="5" style="font-size:13px; font-weight:700; color:#64748b; padding:8px 12px; background:#f8fafc;">${relDavr}</td>`;
            tbody.appendChild(trDate);
            lastDavr = relDavr;
        }
        const m2Val = (Number(rec.totalM2) || 0).toLocaleString('uz-UZ', {
            minimumFractionDigits: 1,
            maximumFractionDigits: 1
        });
        const monthClean = String(rec.month || '').replace(/^_+/, '').replace(/^'/, '');
        const config = (typeof myPermissions !== 'undefined' && Array.isArray(myPermissions.workflowConfig)) ? myPermissions.workflowConfig : [];
        const totalSteps = config.length >= 2 ? config.length : 3;
        const currentStepIdx = Number(rec.currentStep) || 1;
        const phaseColors = getWorkflowStepColors(Math.max(0, currentStepIdx - 1), totalSteps);
        const status = rec.status || 'yangi';
        let stIcon = '🟡';
        if (status.indexOf('yigi') !== -1) stIcon = '🔵';
        else if (status.indexOf('tayyor') !== -1 || status.indexOf('landi') !== -1) stIcon = '🟢';

        const trData = document.createElement('tr');
        trData.className = 'kv-data-row';
        trData.addEventListener('click', () => showKvDetailModal(origIdx));
        trData.innerHTML = `<td class="kv-col-seq">${globalIdx + 1}</td><td class="kv-col-no">${escapeHtml(String(rec.no || '—'))}</td><td class="kv-col-oy">${monthClean || '—'}</td><td class="kv-col-m2">${m2Val}</td><td class="kv-col-st" title="${escapeHtml(status)}"><span style="display:inline-flex;align-items:center;gap:6px;"><span style="width:10px;height:10px;border-radius:50%;background:${phaseColors.bg};border:1px solid ${phaseColors.color};"></span>${stIcon}</span></td>`;
        tbody.appendChild(trData);
    });

    table.appendChild(tbody);
    wrap.appendChild(table);
    fragment.appendChild(wrap);

    if (totalPages > 1) {
        const paginationDiv = document.createElement('div');
        paginationDiv.className = 'pagination';
        paginationDiv.style.cssText = 'display:flex; justify-content:center; gap:8px; padding:20px 0; flex-wrap:wrap;';
        for (let i = 1; i <= totalPages; i++) {
            const btn = document.createElement('button');
            btn.className = `page-btn ${i === kvCurrentPage ? 'active' : ''}`;
            btn.onclick = () => goToKvPage(i);
            btn.innerText = i;
            paginationDiv.appendChild(btn);
        }
        fragment.appendChild(paginationDiv);
    }

    container.innerHTML = '';
    container.appendChild(fragment);

    if (totalDisplay) totalDisplay.innerText = totalM2ForFiltered.toLocaleString('uz-UZ', {
        maximumFractionDigits: 2
    });
    if (typeof renderKvWorkerStats === 'function') renderKvWorkerStats(kvFilteredRecords);
}

function goToKvPage(page) {
    kvCurrentPage = page;
    renderKvList();
    document.getElementById('kvList').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

function showKvDetailModal(idx) {
    const rec = kvFilteredRecords[idx];
    if (!rec) return;
    const m2Val = (Number(rec.totalM2) || 0).toLocaleString('uz-UZ', {
        maximumFractionDigits: 2
    });
    let claimBtnHtml = '';
    const status = rec.status || 'yangi';
    const config = (typeof myPermissions !== 'undefined' && Array.isArray(myPermissions.workflowConfig)) ? myPermissions.workflowConfig : [];
    const myPoss = (typeof myPermissions !== 'undefined' && Array.isArray(myPermissions.positions)) ? myPermissions.positions : [];
    const currentStepIdx = Number(rec.currentStep) || 1;
    const nextStep = config.find(s => s.index === currentStepIdx + 1);
    if (nextStep && (myRole === 'SuperAdmin' || myPoss.indexOf(nextStep.position) !== -1)) {
        const totalSteps = config.length >= 2 ? config.length : 3;
        const nextStepIdx = Number(nextStep.index || currentStepIdx + 1) - 1;
        const nextColors = getWorkflowStepColors(nextStepIdx, totalSteps);
        claimBtnHtml = `<button class="btn-main" style="background:${nextColors.bg};color:${nextColors.color};margin-bottom:10px;" onclick="closeKvDetailModal();claimKvWork(${rec.rowId})">✅ ${escapeHtml(nextStep.action)}</button>`;
    }
    let historyHtml = '';
    const logs = rec.logs || [];
    logs.forEach(log => {
        const totalSteps = config.length >= 2 ? config.length : 3;
        const stepCfg = config.find(s => s.index === log.step);
        const stepIdx = stepCfg ? (Number(stepCfg.index || 1) - 1) : 0;
        const phaseColors = getWorkflowStepColors(stepIdx, totalSteps);
        const name = (log.uid === rec.ownerTgId) ? rec.staffName : (globalEmployeeList && globalEmployeeList.find(e => e.tgId == log.uid)?.username || log.uid);
        historyHtml += `<div style="border-left:2px solid ${phaseColors.bg};padding-left:12px;margin-bottom:12px;position:relative;"><div style="width:10px;height:10px;border-radius:50%;background:${phaseColors.bg};position:absolute;left:-6px;top:4px;"></div><div style="font-size:12px;font-weight:700;color:${phaseColors.color};">${escapeHtml(stepCfg ? stepCfg.status : 'Bajarildi')}</div><div style="font-size:11px;color:var(--text-muted);">${escapeHtml(name)}• ${new Date(log.d).toLocaleString('uz-UZ')}</div></div>`;
    });
    const editBtn = myPermissions.canEdit || myRole === 'SuperAdmin' ? `<button class="kv-edit-btn" style="flex:1;padding:11px;border-radius:10px;background:#FEF3C7;color:#92400E;border:1.5px solid #FCD34D;font-weight:700;font-size:13px;cursor:pointer;" onclick="closeKvDetailModal();openKvModal(${rec.rowId})">✏️ Tahrirlash</button>` : '';
    const deleteBtn = myPermissions.canDelete || myRole === 'SuperAdmin' ? `<button class="kv-delete-btn" style="flex:1;padding:11px;border-radius:10px;background:#FEE2E2;color:#991B1B;border:1.5px solid #FECACA;font-weight:700;font-size:13px;cursor:pointer;" onclick="closeKvDetailModal();deleteKv(${rec.rowId})">🗑 O'chirish</button>` : '';
    const buttonsRow = (editBtn || deleteBtn) ? `<div style="display:flex;gap:8px;margin-bottom:12px;">${editBtn}${deleteBtn}</div>` : '';
    document.getElementById('kvDetailModalBody').innerHTML = `<div class="modal-drag"></div>${buttonsRow}<div class="detail-header"><span class="detail-badge uzs" style="background:#EFF6FF;color:#1D4ED8;">📐 Ish Oqimi Tarixi</span><div class="detail-comment">📌 ${escapeHtml(rec.orderName || '—')}</div><div class="detail-date">📅 №${escapeHtml(String(rec.no || '—'))}|Sana:${escapeHtml(rec.date || '—')}</div></div><div class="detail-card" style="margin-bottom:15px;background:#F8FAFC;"><div class="detail-row"><span class="detail-key">Mas'ul hodim</span><span class="detail-val">${escapeHtml(rec.staffName || '—')}</span></div></div><div class="card" style="margin-bottom:15px;background:#F8FAFC;"><div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--text-muted);margin-bottom:10px;">📉 Jarayon tarixi</div>${historyHtml || '<p style="font-size:12px;color:var(--text-muted);">Tarix bo\'sh</p>'}</div><div class="detail-card"><div class="detail-row"><span class="detail-key">Hozirgi Status</span><span class="detail-val"><b>${escapeHtml(status.toUpperCase())}</b></span></div><div class="detail-row"><span class="detail-key">Jami m²</span><span class="detail-val" style="color:#0F172A;font-size:18px;">${m2Val}m²</span></div></div>${claimBtnHtml}<button class="btn-secondary" style="margin-top:12px;width:100%;" onclick="closeKvDetailModal()">✕ Yopish</button>`;
    document.getElementById('kvDetailModal').classList.remove('hidden');
    if (tg && tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
}

function closeKvDetailModal() {
    document.getElementById('kvDetailModal').classList.add('hidden');
}

function applyKvFilters() {
    const month = document.getElementById('kvFilterMonth')?.value || 'all';
    const year = document.getElementById('kvFilterYear')?.value || 'all';
    const staff = document.getElementById('kvFilterStaff')?.value || 'all';
    const process = document.getElementById('kvFilterProcess')?.value || 'all';
    kvFilteredRecords = kvFullRecords.filter(rec => {
        // Filtrlash: faqat rowId yoki no mavjud bo'lgan haqiqiy yozuvlarni qoldiramiz
        if (!rec || (!rec.rowId && !rec.no)) return false;

        if (month !== 'all') {
            const cleanMonth = String(rec.month || '').replace(/^_+/, '').replace(/^'/, '');
            if (cleanMonth !== month) return false;
        }
        if (year !== 'all') {
            const recYear = rec.year || (rec.date ? rec.date.split('/').pop() : '');
            if (String(recYear) !== String(year)) return false;
        }
        if (staff !== 'all') {
            var staffMatch = (rec.staffName === staff);
            if (!staffMatch && Array.isArray(rec.logs)) {
                var logNames = rec.logs.map(function(log) {
                    if (!log || !log.uid) return '';
                    if (String(log.uid) === String(rec.ownerTgId)) return rec.staffName;
                    var mapped = (typeof window._kvEmpMap !== 'undefined' && window._kvEmpMap[String(log.uid)]) || '';
                    if (!mapped && typeof globalEmployeeList !== 'undefined' && Array.isArray(globalEmployeeList)) {
                        const emp = globalEmployeeList.find(e => String(e.tgId) === String(log.uid));
                        if (emp) mapped = emp.username;
                    }
                    return mapped || String(log.uid);
                });
                staffMatch = logNames.some(function(name) {
                    return name === staff;
                });
            }
            if (!staffMatch) return false;
        }
        if (process !== 'all') {
            if (!rec.currentStep || String(rec.currentStep) !== String(process)) return false;
        }
        return true;
    });
    kvCurrentPage = 1;
    renderKvList();
}

function openKvModal(rowId = null) {
    const modal = document.getElementById('kvadratModal');
    const title = document.getElementById('kvModalTitle');
    const form = document.getElementById('kvForm');
    form.reset();
    document.getElementById('kvRowId').value = rowId || '';
    _initKvFormYears();
    if (rowId) {
        title.innerText = '✏️ Tahrirlash';
        const rec = kvFullRecords.find(r => String(r.rowId) === String(rowId));
        if (rec) {
            document.getElementById('kvOrderNumber').value = rec.no || '';
            document.getElementById('kvOrderName').value = rec.orderName || '';
            document.getElementById('kvTotalM2Input').value = rec.totalM2 || '';
            document.getElementById('kvStaffSelect').value = rec.staffName || '';
            const cleanMonth = String(rec.month || '').replace(/^_+/, '').replace(/^'/, '');
            const monthEl = document.getElementById('kvActionMonth');
            if (monthEl && cleanMonth) monthEl.value = cleanMonth.padStart(2, '0');
            const yearEl = document.getElementById('kvActionYear');
            if (yearEl) {
                if (rec.year) {
                    yearEl.value = rec.year;
                } else if (rec.date) {
                    const parts = String(rec.date).split('/');
                    if (parts.length === 3) yearEl.value = parts[2];
                }
            }
        }
    } else {
        const positions = (typeof myPermissions !== 'undefined' && myPermissions.positions) || [];
        if (myRole !== 'SuperAdmin' && positions.indexOf('Loyihachi') === -1) {
            showToastMsg('❌ Faqat "Loyihachi" buyurtma qo\'sha oladi', true);
            return;
        }
        title.innerText = '📐 Yangi o\'lchov kiritish';
        if (typeof globalEmployeeList !== 'undefined' && globalEmployeeList.includes(myUsername)) {
            const sel = document.getElementById('kvStaffSelect');
            if (sel) sel.value = myUsername;
        }
    }
    modal.classList.remove('hidden');
    if (tg && tg.HapticFeedback) tg.HapticFeedback.impactOccurred('medium');
}

function closeKvModal() {
    document.getElementById('kvadratModal').classList.add('hidden');
}

async function saveKv() {
    const rowId = document.getElementById('kvRowId').value;
    const orderNumber = (document.getElementById('kvOrderNumber').value || '').trim();
    const orderName = (document.getElementById('kvOrderName').value || '').trim();
    const totalM2 = parseFloat(document.getElementById('kvTotalM2Input').value) || 0;
    const staffName = document.getElementById('kvStaffSelect').value;
    const month = document.getElementById('kvActionMonth')?.value || '';
    const year = document.getElementById('kvActionYear')?.value || new Date().getFullYear();
    const monthStr = (year && month) ? `_${month}` : '';
    if (!orderNumber || !orderName || totalM2 <= 0 || !staffName) {
        showToastMsg('❌ Ma\'lumotlarni to\'liq kiriting', true);
        return;
    }
    const duplicateOrder = (kvFullRecords || []).some(rec => {
        if (!rec || !rec.no) return false;
        if (String(rec.rowId) === String(rowId)) return false;
        return String(rec.no || '').trim().toLowerCase() === String(orderNumber).trim().toLowerCase();
    });
    if (duplicateOrder) {
        showToastMsg('❌ Bu Buyurtma № oldin qoshilgan. Iltimos, boshqa raqam kiriting.', true);
        return;
    }
    let ownerTgId = telegramId;
    if (typeof window._kvEmpMap !== 'undefined') {
        const found = Object.entries(window._kvEmpMap).find(([id, name]) => name === staffName);
        if (found) ownerTgId = found[0];
    }
    const saveBtn = document.querySelector('#kvForm .btn-main[type="submit"]');
    setButtonLoading(saveBtn, true, 'Saqlanmoqda...');
    try {
        const action = rowId ? 'kvadrat_edit' : 'kvadrat_add';
        const data = await apiRequest({
            action,
            rowId: rowId || undefined,
            no: orderNumber,
            orderName,
            totalM2,
            staffName,
            ownerTgId,
            month: monthStr,
            year: year
        });
        if (data.success) {
            showToastMsg('✅ Saqlandi');
            closeKvModal();
            initKvadratTab();
        } else {
            showToastMsg('❌ ' + (data.error || 'Saqlashda xato'), true);
        }
    } catch (e) {
        showToastMsg('❌ Tarmoq xatosi', true);
    } finally {
        setButtonLoading(saveBtn, false);
    }
}

async function deleteKv(rowId) {
    if (!confirm("O'chirishga ishonchingiz komilmi?")) return;
    kvShowProc('O\'chirilmoqda...');
    try {
        const data = await apiRequest({
            action: 'kvadrat_delete',
            rowId
        });
        if (data.success) {
            kvHideProc(true, 'O\'chirildi');
            initKvadratTab();
        } else {
            kvHideProc(false, data.error || 'Xato');
        }
    } catch (e) {
        kvHideProc(false, 'Tarmoq xatosi');
    }
}

async function claimKvWork(rowId) {
    kvShowProc('Bajarilmoqda...');
    try {
        const data = await apiRequest({
            action: 'kvadrat_claim',
            rowId
        });
        if (data.success) {
            kvHideProc(true, 'Bajarildi!');
            initKvadratTab();
        } else {
            kvHideProc(false, data.error || 'Xato');
        }
    } catch (e) {
        kvHideProc(false, 'Tarmoq xatosi');
    }
}